import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axios from 'axios'
import { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setData } from './Reducer/userSlice';

function Login() {
  let navigate = useNavigate();
  let dispatch = useDispatch();
  let [loginData, setLogin] = useState({
    email: "",
    password: ""
  })
  useEffect(()=>{
    if(localStorage.getItem("auth_token")){
      navigate('/home')
    }else{
      navigate()
    }
  },[])

  // function getData() {
  //   axios.get("http://agaram.academy/api/action.php?request=getAllMembers",{token:localStorage.getItem("auth_token")}).then(function(response){
  //           console.log(response.data.data)   
  //           })
  //         }
  function checkUser() {
    axios.post("http://agaram.academy/api/action.php?request=getAllMembers").then(function (response) {
      console.log(response.data.data)
      let userData = response.data.data
      localStorage.setItem('auth_token', true)
        navigate("/home")
        dispatch(setData(response.data.data))
      // if (loginData.email == userData.email && loginData.password == userData.password) {
        
      // } else {
      //   alert("Enter Correct Details")
      // }
    })
  }



  // function checkUser() {
  //   axios({
  //       method: 'POST',
  //       url: 'http://agaram.academy/api/action.php',
  //       Data: {
  //           request:"create_candidate",
  //           email:"barish@gmail.com",
  //           password:123456
  //       }
  //   }).then(function (response) {
  //       console.log(response)
  //       navigate("/home")
  //   })
  // };

  return (
    <Form>
      {/* {JSON.stringify(loginData)} */}
      <h2>Login Page</h2><br />
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" defaultValue={"barish@gmail.com"} onKeyUp={(e) => setLogin({ ...loginData, email: e.target.value })} placeholder="Enter email" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" defaultValue={"pass@123"} onKeyUp={(e) => setLogin({ ...loginData, password: e.target.value })} placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group>
      <Button type='button' onClick={() => checkUser()}>Submit</Button>
      <Button type='button' onClick={() => navigate("/register")}>For Register</Button>
    </Form>
  );
}


export default Login;