import Table from 'react-bootstrap/Table';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useSelector } from 'react-redux/es/hooks/useSelector';
import { useDispatch } from 'react-redux';
import { setData,logoutAction } from './Reducer/userSlice';
function Home() {
    let name = useSelector((state) => state.user.value)
    // let [tableData, updateData] = useState([])
    let navigate = useNavigate();
    let dispatch = useDispatch();

        useEffect(() => {
            if (localStorage.getItem("auth_token")) {
                axios.get("http://agaram.academy/api/action.php?request=getAllMembers").then(function (response) {
                    // updateData(response.data.data)
                    dispatch(setData(response.data.data))
                    // console.log(response.data.data)
                })
            } else {
                navigate('/')
            }
        }, [])

    function Logout() {
        localStorage.removeItem('auth_token')
        dispatch(logoutAction({}))
        navigate('/')
    }

    return (
        <>
            <h2>Welcome</h2><button type='button' onClick={() => Logout()}>Logout</button>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Adhaar No</th>
                        <th>Address</th>
                    </tr>
                </thead>
                <tbody>
                    {name.map((data) => {
                        return (
                            <tr>
                                <td>{data.id}</td>
                                <td>{data.name}</td>
                                <td>{data.email}</td>
                                <td>{data.password}</td>
                                <td>{data.aadhar}</td>
                                <td>{data.address}</td>
                            </tr>
                        )
                    })}
                </tbody>
            </Table>
            {/* <b>{JSON.stringify(name)}</b> */}
        </>
    )
}

export default Home;