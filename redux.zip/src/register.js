import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axios from 'axios'
import { useState } from 'react';

function Register() {
    let [userData,setUserData]=useState({
        name:"",
        email:"",
        password:"",
        address:"",
    })
    function postData() {
        axios({
            method: 'POST',
            url: 'http://agaram.academy/api/action.php',
            Data: {
                request:"create_candidate",
                data:userData
            }
        }).then(function (response) {
            console.log(response)
        })
    };


    return (
        <Form>
            {JSON.stringify(userData)}
            <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control onKeyUp={(e)=>setUserData({...userData,name:e.target.value})} placeholder="Enter Name" />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" onKeyUp={(e)=>setUserData({...userData,email:e.target.value})} placeholder="Enter email" />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" onKeyUp={(e)=>setUserData({...userData,password:e.target.value})} placeholder="Password" />
            </Form.Group>

            <Form.Group className="mb-3" >
                <Form.Label>address</Form.Label>
                <Form.Control onKeyUp={(e)=>setUserData({...userData,address:e.target.value})} placeholder="Enter Address" />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicCheckbox">
                <Form.Check type="checkbox" label="Check me out" />
            </Form.Group>
            <Button variant="primary" onClick={() => postData()} type="button">
                Submit
            </Button>
        </Form>
    );
}

export default Register;