import { createSlice } from '@reduxjs/toolkit'

export const regSlice = createSlice({
  name: 'reg',
  initialState: {
    value: [],
  },
  reducers: {
    setData: (state,action) => {
      state.value=action.payload
    },
    logoutAction:(state,action)=>{
      state.value=action.payload
    }
  },
})

export const { setData,logoutAction } = regSlice.actions

export default regSlice.reducer