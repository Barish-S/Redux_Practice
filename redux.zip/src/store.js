import { configureStore } from '@reduxjs/toolkit'
import userReducer from './Reducer/userSlice';
import regReducer from './Reducer/regSlice'
const store= configureStore({
  reducer: {
    user:userReducer,
    reg:regReducer
  },

})

export default store;